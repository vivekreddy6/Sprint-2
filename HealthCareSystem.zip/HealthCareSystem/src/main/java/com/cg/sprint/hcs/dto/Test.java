package com.cg.sprint.hcs.dto;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="test")
public class Test 
{
	@Id
	@Column(name="test_id")
	int testId;
	@Column(name="test_name")
	String testName;
	@Column(name="center_id")
	DiagnosticCenter diagCen;
	
	public Test() {super();}

	public Test(int testId, String testName, DiagnosticCenter diagCen) {
		super();
		this.testId = testId;
		this.testName = testName;
		this.diagCen= diagCen;
	}

	public int getTestId() {
		return testId;
	}

	public void setTestId(int testId) {
		this.testId = testId;
	}

	public String getTestName() {
		return testName;
	}

	public void setTestName(String testName) {
		this.testName = testName;
	}

	public DiagnosticCenter getDiagCen() {
		return diagCen;
	}

	public void setDiagCen(DiagnosticCenter diagCen) {
		this.diagCen = diagCen;
	}
	
}
