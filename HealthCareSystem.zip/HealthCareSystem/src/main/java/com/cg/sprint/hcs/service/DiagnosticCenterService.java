package com.cg.sprint.hcs.service;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.cg.sprint.hcs.dao.DiagnosticCenterDAO;
import com.cg.sprint.hcs.dto.DiagnosticCenter;

@Service
public class DiagnosticCenterService 
{
	 @Autowired
	    DiagnosticCenterDAO dcDao;
	    public void setDiagnosticCenterDAO(DiagnosticCenterDAO dcDao)
	    {
	    	this.dcDao=dcDao;
	    } 
		
	    @Transactional(readOnly=true)
	    public DiagnosticCenter getDiagnosticCenter(int centerId)
	    {
	    	return dcDao.findById(centerId).get();
	    }
	    
	    @Transactional(readOnly=true)
	    public List<DiagnosticCenter> getDiagnosticCenters()
	    {
	    	return dcDao.findAll();
	    }
	    
	    @Transactional
	    public DiagnosticCenter insertDiagnosticCenter(DiagnosticCenter diagCen)
	    {
	        return dcDao.save(diagCen);
	    }
	    
	    @Transactional
	    public String deleteDiagnosticCenter(int centerId)
	    {
	    	dcDao.deleteById(centerId);
	    	return "center Deleted";
	    }
}


