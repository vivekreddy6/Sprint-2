package com.cg.sprint.hcs.dto;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
@Entity

public class DiagnosticCenter 
{
	@Id
	@Column(name="center_id")
	int centerId;
	@Column(name="center_name")
	String centerName;
	@Column(name="center_address")
	String centerAddress;
	
	public DiagnosticCenter() {super();}

	public DiagnosticCenter(int centerId, String centerName, String centerAddress) {
		super();
		this.centerId = centerId;
		this.centerName = centerName;
		this.centerAddress = centerAddress;
	}

	public int getCenterId() {
		return centerId;
	}

	public void setCenterId(int centerId) {
		this.centerId = centerId;
	}

	public String getCenterName() {
		return centerName;
	}

	public void setCenterName(String centerName) {
		this.centerName = centerName;
	}

	public String getCenterAddress() {
		return centerAddress;
	}

	public void setCenterAddress(String centerAddress) {
		this.centerAddress = centerAddress;
	}

}
