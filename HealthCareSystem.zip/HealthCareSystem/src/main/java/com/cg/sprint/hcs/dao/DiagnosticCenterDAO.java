package com.cg.sprint.hcs.dao;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.cg.sprint.hcs.dto.DiagnosticCenter;

@Repository
public interface DiagnosticCenterDAO extends JpaRepository<DiagnosticCenter,Integer>
{
}
