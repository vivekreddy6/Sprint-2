/*
 * package com.cg.hcsAdmin.dto;
 * 
 * import java.time.LocalDate;
 * 
 * import javax.persistence.Column; import javax.persistence.Entity; import
 * javax.persistence.Id; import javax.persistence.JoinColumn; import
 * javax.persistence.OneToMany; import javax.persistence.OneToOne;
 * 
 * @Entity public class Appointment {
 * 
 * @Id
 * 
 * @Column(name = "appointment_id") private Integer appointmentId;
 * 
 * @Column(name = "test_name") private String test_name;
 * 
 * @Column(name = "user_id") private String user_id;
 * 
 * @JoinColumn(name = "center_id") private int centerId;
 * 
 * @OneToOne
 * 
 * @JoinColumn(name = "test_id") private Test test;
 * 
 * @Column(name="appointment_date") LocalDate appointmentDate;
 * 
 * @Column(name = "slot") private Integer slot; public Appointment() {} public
 * Appointment(Integer appointmentId, String test_name, String user_id, int
 * centerId, Test test, LocalDate appointmentDate, Integer slot) { super();
 * this.appointmentId = appointmentId; this.test_name = test_name; this.user_id
 * = user_id; this.centerId = centerId; this.test = test; this.appointmentDate =
 * appointmentDate; this.slot = slot; } public Integer getAppointmentId() {
 * return appointmentId; } public void setAppointmentId(Integer appointmentId) {
 * this.appointmentId = appointmentId; } public String getTest_name() { return
 * test_name; } public void setTest_name(String test_name) { this.test_name =
 * test_name; } public String getUser_id() { return user_id; } public void
 * setUser_id(String user_id) { this.user_id = user_id; } public int
 * getCenterId() { return centerId; } public void setCenterId(int centerId) {
 * this.centerId = centerId; } public Test getTest() { return test; } public
 * void setTest(Test test) { this.test = test; } public LocalDate
 * getAppointmentDate() { return appointmentDate; } public void
 * setAppointmentDate(LocalDate appointmentDate) { this.appointmentDate =
 * appointmentDate; } public Integer getSlot() { return slot; } public void
 * setSlot(Integer slot) { this.slot = slot; }
 * 
 * 
 * 
 * 
 * }
 */